﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NetflixChecker
{
    class Account
    {
        public string success { get; set; }
        public string limit { get; set; }
        public string account { get; set; }
        public string screens { get; set; }
        public string language { get; set; }

        public string until { get; set; }
        public string working { get; set; }

    }
}
